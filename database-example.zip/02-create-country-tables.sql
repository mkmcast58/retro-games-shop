USE `full-stack-ecommerce`;

SET foreign_key_checks = 0;

--
-- Table structure for table `country`
--

DROP TABLE IF EXISTS `country`;

CREATE TABLE `country` (
  `id` smallint unsigned NOT NULL,
  `code` varchar(2) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB;

--
-- Data for table `country`
--

INSERT INTO `country` VALUES 
(1,'PL','Poland'),
(2,'CA','Canada'),
(3,'DE','Germany'),
(6,'US','United States');

--
-- Table structure for table `state`
--

DROP TABLE IF EXISTS `state`;

CREATE TABLE `state` (
  `id` smallint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `country_id` smallint unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_country` (`country_id`),
  CONSTRAINT `fk_country` FOREIGN KEY (`country_id`) REFERENCES `country` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1;

--
-- Dumping data for table `state`
--

INSERT INTO `state` VALUES 
(1,'dolnośląskie',1),
(2,'kujawskie',1),
(3,'lubelskie',1),
(4,'lubuskie',1),
(5,'pomorskie',1),
(6,'łódzkie',1),
(7,'małopolskie',1),
(8,'mazowieckie',1),
(9,'opolskie',1),
(10,'podkarpackie',1),
(11,'podlaskie',1),
(12,'pomorskie',1),
(13,'śląskie',1),
(14,'świętokrzyskie',1),
(15,'warmińsko-mazurskie',1),
(16,'wielkopolskie',1),
(17,'zachodniopomorskie',1),
(18,'Alberta',2),
(19,'British Columbia',2),
(20,'Manitoba',2),
(21,'New Brunswick',2),
(22,'Newfoundland and Labrador',2),
(23,'Northwest Territories',2),
(24,'Nova Scotia',2),
(25,'Nunavut',2),
(26,'Ontario',2),
(27,'Prince Edward Island',2),
(28,'Quebec',2),
(39,'Saskatchewan',2),
(30,'Yukon',2),
(31,'Baden-Württemberg',3),
(32,'Bavaria',3),
(33,'Berlin',3),
(34,'Brandenburg',3),
(35,'Bremen',3),
(36,'Hamburg',3),
(37,'Hesse',3),
(38,'Lower Saxony',3),
(39,'Mecklenburg-Vorpommern',3),
(40,'North Rhine-Westphalia',3),
(41,'Rhineland-Palatinate',3),
(42,'Saarland',3),
(43,'Saxony',3),
(44,'Saxony-Anhalt',3),
(45,'Schleswig-Holstein',3),
(46,'Alabama',4),
(47,'Alaska',4),
(48,'Arizona',4),
(49,'Arkansas',4),
(50,'California',4),
(51,'Colorado',4),
(52,'Connecticut',4),
(53,'Delaware',4),
(54,'District Of Columbia',4),
(55,'Florida',4),
(56,'Georgia',4),
(57,'Hawaii',4),
(58,'Idaho',4),
(59,'Illinois',4),
(60,'Indiana',4),
(61,'Iowa',4),
(62,'Kansas',4),
(63,'Kentucky',4),
(64,'Louisiana',4),
(65,'Maine',4),
(66,'Maryland',4),
(67,'Massachusetts',4),
(68,'Michigan',4),
(69,'Minnesota',4),
(70,'Mississippi',4),
(81,'Missouri',4),
(82,'Montana',4),
(83,'Nebraska',4),
(84,'Nevada',4),
(85,'New Hampshire',4),
(86,'New Jersey',4),
(87,'New Mexico',4),
(88,'New York',4),
(89,'North Carolina',4),
(90,'North Dakota',4),
(91,'Ohio',4),
(92,'Oklahoma',4),
(93,'Oregon',4),
(94,'Pennsylvania',4),
(95,'Rhode Island',4),
(96,'South Carolina',4),
(97,'South Dakota',4),
(98,'Tennessee',4),
(99,'Texas',4),
(100,'Utah',4),
(101,'Vermont',4),
(102,'Virginia',4),
(103,'Washington',4),
(104,'West Virginia',4),
(105,'Wisconsin',4),
(106,'Wyoming',4);


SET foreign_key_checks = 1;